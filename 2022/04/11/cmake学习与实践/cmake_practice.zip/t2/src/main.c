#include <stdio.h>

int main(int argc, char const *argv[])
{
    if(argc == 1){
        printf("Hello world!\r\n");
    }else{
        printf("Hello %s!\r\n" , argv[1]);
    }
    return 0;
}
