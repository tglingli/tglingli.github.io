#include <hello.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
    HelloFunc();
    system("pause");
    return 0;
}
