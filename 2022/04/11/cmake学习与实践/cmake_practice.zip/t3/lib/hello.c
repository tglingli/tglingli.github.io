#include "hello.h"

void HelloFunc()
{
    printf("Hello world\r\n");
}