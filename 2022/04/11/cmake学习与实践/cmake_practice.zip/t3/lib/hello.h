#ifndef __Hello_H__
#define __Hello_H__

#include <stdio.h>

void HelloFunc();

#endif // !__Hello_H__