#include <hello.h>

int main(int argc, char const *argv[])
{
    HelloFunc();
    return 0;
}
